Para esta aplicação funcionar é necessário que o seguinte programa esteja instalado na máquina:

- SQL Server Compact 4.0 SP1 (x64)

Esse programa pode ser baixado na seguinte URL: https://www.microsoft.com/pt-br/download/details.aspx?id=30709.

Após confirmar que este programa está instalado na máquina clique no arquivo BasicSalesSetup.msi e complete a instalação.

Por fim, aproveite o aplicativo Basic Sales!
